import { siteConfig } from '../config/siteConfig.js';

/** Normalisasi nomor HP Indonesia ke format 62xxxxxxxxxx. Mengembalikan '' jika tidak valid. */
export function normalizeIndonesianPhone(raw) {
  const cleaned = String(raw ?? '').replace(/[\s\-().]/g, '');
  if (!/^(\+?62|0)8\d{7,12}$/.test(cleaned)) return '';
  if (cleaned.startsWith('+62')) return cleaned.slice(1);
  if (cleaned.startsWith('62')) return cleaned;
  return `62${cleaned.slice(1)}`;
}

export function todayISO(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function validateBooking(v, today = todayISO()) {
  const e = {};
  if (!v.fullName || v.fullName.trim().length < 3) e.fullName = 'Masukkan nama lengkap (minimal 3 karakter).';
  if (!v.whatsapp || !normalizeIndonesianPhone(v.whatsapp)) e.whatsapp = 'Masukkan nomor WhatsApp yang valid, contoh: 0812xxxxxxxx atau +62812xxxxxxxx.';
  if (!v.vehicle) e.vehicle = 'Pilih kendaraan.';
  if (!v.date) e.date = 'Pilih tanggal.';
  else if (v.date < today) e.date = 'Tanggal tidak boleh di masa lalu.';
  if (!v.time) e.time = 'Pilih waktu.';
  if (!v.branch) e.branch = 'Pilih lokasi atau cabang.';
  if (!v.consent) e.consent = 'Anda perlu menyetujui penggunaan data agar permintaan dapat ditindaklanjuti.';
  return e;
}

/**
 * Kirim booking ke backend jika dikonfigurasi. Mengembalikan { channel }.
 *  - 'supabase' / 'api' → tersimpan di backend
 *  - 'whatsapp'         → tidak ada backend; pengguna melanjutkan lewat WhatsApp
 * Melempar Error jika backend dikonfigurasi tetapi gagal — status tidak dipalsukan.
 */
export async function submitBooking(payload, backend = siteConfig.backend, table = siteConfig.booking.supabaseTable) {
  if (backend.supabaseUrl && backend.supabaseAnonKey) {
    const res = await fetch(`${backend.supabaseUrl.replace(/\/$/, '')}/rest/v1/${table}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: backend.supabaseAnonKey,
        Authorization: `Bearer ${backend.supabaseAnonKey}`,
        Prefer: 'return=minimal',
      },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`Penyimpanan gagal (HTTP ${res.status}).`);
    return { channel: 'supabase' };
  }
  if (backend.apiUrl) {
    const res = await fetch(backend.apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`Pengiriman ke server gagal (HTTP ${res.status}).`);
    return { channel: 'api' };
  }
  return { channel: 'whatsapp' };
}
