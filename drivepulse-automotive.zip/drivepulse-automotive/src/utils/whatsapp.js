import { siteConfig } from '../config/siteConfig.js';
import { formatIDR } from './format.js';

/** Hapus semua karakter non-digit (+, spasi, tanda hubung) dari nomor. */
export function sanitizeWhatsAppNumber(raw) {
  return String(raw ?? '').replace(/\D/g, '');
}

export function isWhatsAppConfigured(number = siteConfig.whatsapp.number) {
  return sanitizeWhatsAppNumber(number).length >= 8;
}

/**
 * Bangun URL WhatsApp resmi.
 * - Nomor terkonfigurasi → https://wa.me/<nomor>?text=<pesan>
 * - Nomor kosong → https://wa.me/?text=<pesan> (pengguna memilih kontak sendiri; tidak ada nomor karangan)
 */
export function buildWhatsAppUrl(message = '', number = siteConfig.whatsapp.number) {
  const digits = sanitizeWhatsAppNumber(number);
  const text = encodeURIComponent(message);
  return digits.length >= 8 ? `https://wa.me/${digits}?text=${text}` : `https://wa.me/?text=${text}`;
}

const hello = () => `Halo ${siteConfig.whatsapp.salesName}`;

export const waMessages = {
  general: () => `${hello()}, saya ingin bertanya tentang kendaraan yang tersedia.`,

  car: (car, colorName) =>
    `${hello()}, saya tertarik dengan ${car.brand} ${car.name} ${car.year}${colorName ? ` warna ${colorName}` : ''}. Mohon informasi harga, ketersediaan unit, dan simulasi kredit.`,

  simulation: (sim, carLabel) =>
    [
      `${hello()}, saya sudah mencoba simulasi kredit${carLabel ? ` untuk ${carLabel}` : ''} (simulasi bunga flat, hanya estimasi):`,
      `• Harga kendaraan: ${formatIDR(sim.price)}`,
      `• DP: ${formatIDR(sim.downPayment)} (${sim.dpPercent.toFixed(1)}%)`,
      `• Pokok pembiayaan: ${formatIDR(sim.principal)}`,
      `• Tenor: ${sim.years} tahun (${sim.months} bulan)`,
      `• Bunga: ${sim.annualRatePercent}% per tahun (flat)`,
      `• Estimasi cicilan: ${formatIDR(sim.monthlyInstallment)} / bulan`,
      'Mohon info lebih lanjut tentang penawaran pembiayaan yang tersedia.',
    ].join('\n'),

  booking: (b) =>
    [
      `${hello()}, saya ingin request test drive:`,
      `• Nama: ${b.fullName}`,
      `• WhatsApp: ${b.whatsapp}`,
      `• Kendaraan: ${b.vehicleLabel}`,
      `• Tanggal: ${b.date}`,
      `• Waktu: ${b.time}`,
      `• Lokasi: ${b.branchLabel}`,
      b.notes ? `• Catatan: ${b.notes}` : null,
      'Mohon konfirmasi ketersediaan jadwal. Terima kasih.',
    ]
      .filter(Boolean)
      .join('\n'),
};
