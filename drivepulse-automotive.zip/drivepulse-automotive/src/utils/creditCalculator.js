/**
 * Kalkulator kredit — metode BUNGA FLAT (bukan anuitas).
 *
 *   Pokok pembiayaan   = Harga − DP
 *   Total bunga        = Pokok × bunga tahunan × lama tenor (tahun)
 *   Cicilan per bulan  = (Pokok + Total bunga) / jumlah bulan
 *
 * Biaya tambahan (opsional) diasumsikan dibayar di muka dan TIDAK dibiayai/tidak dikenai bunga.
 */
export const MIN_TENOR_YEARS = 1;
export const MAX_TENOR_YEARS = 5;

export const CREDIT_DISCLAIMER =
  'Simulasi ini hanya estimasi, bukan penawaran pembiayaan resmi. Persetujuan kredit, suku bunga aktual, biaya administrasi, asuransi, dan cicilan akhir mengikuti ketentuan lembaga pembiayaan.';

const toNumber = (v) => (v === '' || v === null || v === undefined ? NaN : Number(v));

export function calculateFlatCredit({
  price,
  dpMode = 'percent', // 'percent' | 'amount'
  dpPercent = 0,
  dpAmount = 0,
  tenorYears,
  annualRatePercent,
  extraFees = 0,
}) {
  const errors = {};

  const p = toNumber(price);
  if (!Number.isFinite(p) || p <= 0) errors.price = 'Harga kendaraan harus lebih dari 0.';

  const years = toNumber(tenorYears);
  if (!Number.isInteger(years) || years < MIN_TENOR_YEARS || years > MAX_TENOR_YEARS) {
    errors.tenorYears = `Tenor harus ${MIN_TENOR_YEARS}–${MAX_TENOR_YEARS} tahun.`;
  }

  const rate = toNumber(annualRatePercent);
  if (!Number.isFinite(rate) || rate < 0 || rate > 100) errors.annualRatePercent = 'Suku bunga harus antara 0–100% per tahun.';

  const fees = extraFees === '' || extraFees === null || extraFees === undefined ? 0 : Number(extraFees);
  if (!Number.isFinite(fees) || fees < 0) errors.extraFees = 'Biaya tambahan tidak boleh negatif.';

  let downPayment = NaN;
  if (dpMode === 'amount') {
    const amt = toNumber(dpAmount);
    if (!Number.isFinite(amt) || amt < 0) errors.dp = 'DP tidak boleh negatif.';
    else if (Number.isFinite(p) && amt > p) errors.dp = 'DP tidak boleh lebih tinggi dari harga kendaraan.';
    else downPayment = amt;
  } else {
    const pct = toNumber(dpPercent);
    if (!Number.isFinite(pct) || pct < 0 || pct > 100) errors.dp = 'Persentase DP harus antara 0–100%.';
    else if (Number.isFinite(p)) downPayment = (p * pct) / 100;
  }

  if (Object.keys(errors).length > 0 || !Number.isFinite(downPayment)) {
    return { ok: false, errors };
  }

  const principal = p - downPayment;
  const totalInterest = principal * (rate / 100) * years;
  const months = years * 12;
  const totalInstallments = principal + totalInterest;
  const monthlyInstallment = totalInstallments / months;
  const totalPayment = downPayment + totalInstallments + fees;

  return {
    ok: true,
    errors: {},
    method: 'flat',
    price: p,
    downPayment,
    dpPercent: (downPayment / p) * 100,
    principal,
    totalInterest,
    months,
    years,
    annualRatePercent: rate,
    monthlyInstallment,
    totalInstallments,
    extraFees: fees,
    totalPayment,
  };
}
