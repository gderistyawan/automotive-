const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

/** Format angka ke Rupiah. Nilai tidak valid → '—'. */
export function formatIDR(value) {
  const n = Number(value);
  if (value === null || value === undefined || value === '' || !Number.isFinite(n)) return '—';
  return idr.format(Math.round(n));
}
