/**
 * SUMBER DATA KENDARAAN TUNGGAL.
 * Semua data di bawah adalah DATA DEMO (isDemo: true) — nama, harga, dan spesifikasi
 * hanya contoh dan BUKAN informasi resmi. Ganti dengan data dealer yang sudah dikonfirmasi,
 * lalu set isDemo: false (atau hapus) pada setiap kendaraan nyata.
 *
 * Field: id, brand, name, year, category, bodyType, fuel, drivetrain, price (IDR OTR, null = belum ada),
 *        image, gallery[], specs[{label,value}], features[], colors[{name,hex}], featured, isDemo
 */
export const CATEGORIES = [
  { value: 'all', label: 'All Cars' },
  { value: 'SUV', label: 'SUV' },
  { value: 'Sedan', label: 'Sedan' },
  { value: 'Hatchback', label: 'Hatchback' },
  { value: 'Electric Vehicle', label: 'Electric Vehicle' },
  { value: 'Hybrid', label: 'Hybrid' },
];

const img = (id) => ({ image: `/images/cars/${id}.svg`, gallery: [`/images/cars/${id}.svg`, `/images/cars/${id}-alt.svg`] });

export const cars = [
  {
    id: 'terra-x', brand: 'DEMO MOTORS', name: 'Terra X', year: 2025, category: 'SUV', bodyType: 'suv',
    fuel: 'Bensin', drivetrain: 'FWD', price: 520000000, featured: true, isDemo: true, ...img('terra-x'),
    specs: [{ label: 'Mesin', value: '1.5L Turbo (demo)' }, { label: 'Transmisi', value: 'Otomatis (demo)' }, { label: 'Kapasitas', value: '7 penumpang (demo)' }],
    features: ['Kamera 360° (demo)', 'Layar infotainment (demo)', 'Atap panoramik (demo)'],
    colors: [{ name: 'Slate Grey', hex: '#3b4a5a' }, { name: 'Pearl White', hex: '#e8eaee' }, { name: 'Midnight', hex: '#15181e' }],
  },
  {
    id: 'ridge-7', brand: 'DEMO MOTORS', name: 'Ridge 7', year: 2025, category: 'SUV', bodyType: 'suv',
    fuel: 'Bensin', drivetrain: 'AWD', price: 640000000, featured: false, isDemo: true, ...img('ridge-7'),
    specs: [{ label: 'Mesin', value: '2.0L Turbo (demo)' }, { label: 'Transmisi', value: 'Otomatis 8-speed (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Mode berkendara multi-medan (demo)', 'Bagasi luas (demo)', 'Asisten jalur (demo)'],
    colors: [{ name: 'Forest', hex: '#2f4a3a' }, { name: 'Sand', hex: '#c9b79c' }],
  },
  {
    id: 'sleek-s', brand: 'DEMO MOTORS', name: 'Sleek S', year: 2025, category: 'Sedan', bodyType: 'sedan',
    fuel: 'Bensin', drivetrain: 'FWD', price: 480000000, featured: true, isDemo: true, ...img('sleek-s'),
    specs: [{ label: 'Mesin', value: '1.5L Turbo (demo)' }, { label: 'Transmisi', value: 'CVT (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Interior kulit sintetis (demo)', 'Sunroof (demo)', 'Lampu LED (demo)'],
    colors: [{ name: 'Graphite', hex: '#2d3037' }, { name: 'Silver', hex: '#a9adb5' }, { name: 'Crimson', hex: '#7a1f2b' }],
  },
  {
    id: 'pulse-one', brand: 'DEMO MOTORS', name: 'Pulse One', year: 2025, category: 'Hatchback', bodyType: 'hatch',
    fuel: 'Bensin', drivetrain: 'FWD', price: 310000000, featured: true, isDemo: true, ...img('pulse-one'),
    specs: [{ label: 'Mesin', value: '1.2L (demo)' }, { label: 'Transmisi', value: 'Manual / CVT (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Ringkas untuk kota (demo)', 'Konektivitas smartphone (demo)', 'Kamera mundur (demo)'],
    colors: [{ name: 'Lime Spark', hex: '#8fb53a' }, { name: 'Pearl White', hex: '#e8eaee' }, { name: 'Black', hex: '#16181d' }],
  },
  {
    id: 'city-h', brand: 'DEMO MOTORS', name: 'City H', year: 2024, category: 'Hatchback', bodyType: 'hatch',
    fuel: 'Bensin', drivetrain: 'FWD', price: 265000000, featured: false, isDemo: true, ...img('city-h'),
    specs: [{ label: 'Mesin', value: '1.2L (demo)' }, { label: 'Transmisi', value: 'Manual (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Irit bahan bakar (demo)', 'Bodi ringkas (demo)'],
    colors: [{ name: 'Ocean', hex: '#2b5b7a' }, { name: 'Silver', hex: '#a9adb5' }],
  },
  {
    id: 'volt-e', brand: 'DEMO MOTORS', name: 'Volt E', year: 2025, category: 'Electric Vehicle', bodyType: 'hatch',
    fuel: 'Listrik', drivetrain: 'RWD', price: 690000000, featured: false, isDemo: true, ...img('volt-e'),
    specs: [{ label: 'Baterai', value: '60 kWh (demo)' }, { label: 'Jarak tempuh', value: '± 400 km (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Pengisian cepat DC (demo)', 'Regenerative braking (demo)', 'OTA update (demo)'],
    colors: [{ name: 'Arctic', hex: '#dfe6ea' }, { name: 'Volt Green', hex: '#6fa02b' }],
  },
  {
    id: 'volt-x', brand: 'DEMO MOTORS', name: 'Volt X', year: 2025, category: 'Electric Vehicle', bodyType: 'suv',
    fuel: 'Listrik', drivetrain: 'AWD', price: 890000000, featured: true, isDemo: true, ...img('volt-x'),
    specs: [{ label: 'Baterai', value: '82 kWh (demo)' }, { label: 'Jarak tempuh', value: '± 500 km (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Dual motor (demo)', 'Head-up display (demo)', 'Asisten parkir otomatis (demo)'],
    colors: [{ name: 'Obsidian', hex: '#111318' }, { name: 'Storm', hex: '#4a5160' }],
  },
  {
    id: 'hybrid-g', brand: 'DEMO MOTORS', name: 'Hybrid G', year: 2025, category: 'Hybrid', bodyType: 'suv',
    fuel: 'Hybrid', drivetrain: 'FWD', price: 560000000, featured: false, isDemo: true, ...img('hybrid-g'),
    specs: [{ label: 'Powertrain', value: '1.8L Hybrid (demo)' }, { label: 'Transmisi', value: 'e-CVT (demo)' }, { label: 'Kapasitas', value: '5 penumpang (demo)' }],
    features: ['Mode EV di kecepatan rendah (demo)', 'Konsumsi efisien (demo)', 'Layar digital (demo)'],
    colors: [{ name: 'Moonstone', hex: '#8b919c' }, { name: 'Deep Blue', hex: '#1f3550' }],
  },
];

export const featuredCars = (() => {
  const f = cars.filter((c) => c.featured);
  return f.length >= 4 ? f : cars.slice(0, 4);
})();

export const getCarById = (id) => cars.find((c) => c.id === id) || null;
