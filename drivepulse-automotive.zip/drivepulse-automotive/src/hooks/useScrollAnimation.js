import { useLayoutEffect } from 'react';
import { gsap } from '../lib/gsap';

/**
 * Menjalankan animasi GSAP/ScrollTrigger dalam gsap.matchMedia sehingga:
 *  - tidak ada animasi jika pengguna memilih prefers-reduced-motion,
 *  - semua tween & ScrollTrigger dibersihkan otomatis saat komponen dilepas / media query berubah.
 *
 * setup({ scope, desktop, mobile, gsap }) dipanggil di dalam konteks matchMedia.
 */
export function useScrollAnimation(scopeRef, setup, deps = []) {
  useLayoutEffect(() => {
    const scope = scopeRef.current;
    if (!scope) return undefined;
    const mm = gsap.matchMedia();
    mm.add(
      {
        motion: '(prefers-reduced-motion: no-preference)',
        desktop: '(min-width: 901px)',
        mobile: '(max-width: 700px)',
      },
      (context) => {
        const { motion, desktop, mobile } = context.conditions;
        if (!motion) return undefined;
        return setup({ scope, desktop, mobile, gsap });
      }
    );
    return () => mm.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
