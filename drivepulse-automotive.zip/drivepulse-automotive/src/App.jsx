import { useCallback, useEffect, useState } from 'react';
import { siteConfig } from './config/siteConfig.js';
import { cars } from './data/cars.js';
import { ScrollTrigger } from './lib/gsap.js';
import { scrollToId } from './utils/scroll.js';
import { waMessages } from './utils/whatsapp.js';
import AnnouncementBar from './components/AnnouncementBar.jsx';
import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import ScrollText from './components/ScrollText.jsx';
import CarShowcase from './components/CarShowcase.jsx';
import CarCatalog from './components/CarCatalog.jsx';
import CarDetails from './components/CarDetails.jsx';
import WhyChooseUs from './components/WhyChooseUs.jsx';
import CreditSimulator from './components/CreditSimulator.jsx';
import TestDriveForm from './components/TestDriveForm.jsx';
import CTASection from './components/CTASection.jsx';
import Footer from './components/Footer.jsx';
import WhatsAppButton from './components/WhatsAppButton.jsx';

export default function App() {
  const [detailCar, setDetailCar] = useState(null);
  const [simCarId, setSimCarId] = useState(cars[0]?.id ?? 'custom');
  const [bookCarId, setBookCarId] = useState('');

  // Metadata dari konfigurasi.
  useEffect(() => {
    document.title = siteConfig.seo.title;
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', siteConfig.seo.description);
  }, []);

  // Hitung ulang posisi ScrollTrigger setelah font/gambar selesai dimuat agar animasi tidak bergeser.
  useEffect(() => {
    const refresh = () => ScrollTrigger.refresh();
    window.addEventListener('load', refresh);
    document.fonts?.ready?.then(refresh);
    let t;
    const onResize = () => {
      clearTimeout(t);
      t = setTimeout(refresh, 200);
    };
    window.addEventListener('orientationchange', onResize);
    return () => {
      window.removeEventListener('load', refresh);
      window.removeEventListener('orientationchange', onResize);
      clearTimeout(t);
    };
  }, []);

  const openDetails = useCallback((car) => setDetailCar(car), []);
  const closeDetails = useCallback(() => setDetailCar(null), []);

  const goSimulate = useCallback((car) => {
    setDetailCar(null);
    setSimCarId(car.id);
    setTimeout(() => scrollToId('simulator'), 120);
  }, []);

  const goBook = useCallback((car) => {
    setDetailCar(null);
    setBookCarId(car.id);
    setTimeout(() => scrollToId('booking'), 120);
  }, []);

  return (
    <>
      <a className="skip-link" href="#explore">
        Lewati ke katalog
      </a>
      <AnnouncementBar />
      <Navbar />
      <main>
        <Hero />
        <ScrollText />
        <CarShowcase onDetails={openDetails} onSimulate={goSimulate} />
        <CarCatalog onDetails={openDetails} onSimulate={goSimulate} />
        <WhyChooseUs />
        <CreditSimulator carId={simCarId} onCarChange={setSimCarId} />
        <TestDriveForm presetCarId={bookCarId} />
        <CTASection />
      </main>
      <Footer />
      <CarDetails car={detailCar} onClose={closeDetails} onSimulate={goSimulate} onBook={goBook} />
      {siteConfig.features.floatingWhatsApp && <WhatsAppButton floating message={waMessages.general()} />}
    </>
  );
}
