/**
 * SATU-SATUNYA tempat untuk identitas dealer, kontak, dan pengaturan fitur.
 * Semua nilai di bawah adalah PLACEHOLDER — ganti dengan data dealer yang sebenarnya.
 * Nilai yang dikosongkan ('') tidak akan ditampilkan di website.
 */
const env = import.meta.env ?? {};

export const siteConfig = {
  name: 'DRIVEPULSE AUTOMOTIVE',
  shortName: 'DRIVEPULSE',
  logo: { src: '/favicon.svg', alt: 'Logo DRIVEPULSE AUTOMOTIVE' },

  seo: {
    title: 'DRIVEPULSE AUTOMOTIVE — Drive Your Future',
    description:
      'Jelajahi koleksi mobil baru, simulasikan kredit, dan jadwalkan test drive bersama DRIVEPULSE AUTOMOTIVE.',
    url: env.VITE_SITE_URL || '',
  },

  // Teks announcement bar. Jangan isi klaim promo yang belum terbukti.
  announcement: 'FIND YOUR NEXT DRIVE — BOOK YOUR TEST DRIVE TODAY',

  whatsapp: {
    // Format internasional tanpa +, spasi, atau tanda hubung. Diatur lewat VITE_WHATSAPP_NUMBER
    // atau isi langsung di sini. Jika kosong, tombol WhatsApp membuka WhatsApp dengan pesan
    // terisi dan pengguna memilih kontak sendiri (tidak ada nomor yang dikarang).
    number: env.VITE_WHATSAPP_NUMBER || '',
    salesName: 'Sales DRIVEPULSE',
  },

  contact: {
    email: '',
    phone: '',
    address: '',
    hours: '',
  },

  // Cabang untuk form test drive. Ganti dengan cabang nyata.
  branches: [{ id: 'main', name: 'Cabang Utama (placeholder — ubah di siteConfig.js)', address: '' }],

  social: { instagram: '', facebook: '', tiktok: '', youtube: '' },

  features: {
    showPrices: true, // false = semua harga disembunyikan ("Hubungi sales")
    floatingWhatsApp: true,
    show3D: true, // false = selalu pakai gambar fallback
    demoBadges: true, // badge "DEMO" pada data contoh. Matikan hanya jika semua data sudah nyata.
  },

  model3D: {
    url: '/models/car.glb', // letakkan file .glb di public/models/. Jika tidak ada, dipakai model placeholder.
    bodyColor: '#2b2f38',
    accent: '#C8FA50',
  },

  credit: {
    defaultRatePercent: 5, // contoh saja — bukan suku bunga resmi
    defaultDpPercent: 20,
  },

  booking: {
    timeSlots: ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00'],
    supabaseTable: 'test_drive_bookings',
  },

  // Backend booking opsional. Jika kosong, booking dikirim lewat WhatsApp.
  backend: {
    supabaseUrl: env.VITE_SUPABASE_URL || '',
    supabaseAnonKey: env.VITE_SUPABASE_ANON_KEY || '',
    apiUrl: env.VITE_BOOKING_API_URL || '',
  },

  whyChooseUs: [
    { icon: 'car', title: 'Pilihan Kendaraan', text: 'Jelajahi berbagai kategori kendaraan dalam satu katalog yang mudah difilter.' },
    { icon: 'headphones', title: 'Bantuan Konsultasi', text: 'Tanyakan kebutuhan Anda ke tim sales sebelum menentukan pilihan.' },
    { icon: 'wallet', title: 'Informasi Pembiayaan', text: 'Gunakan simulator untuk gambaran awal cicilan, lalu diskusikan detailnya dengan sales.' },
    { icon: 'key', title: 'Pendampingan Test Drive', text: 'Jadwalkan test drive dan dapatkan pendampingan saat mencoba kendaraan.' },
    { icon: 'message', title: 'Layanan Sales Responsif', text: 'Hubungi sales langsung lewat WhatsApp dengan pesan yang sudah terisi.' },
  ],
};
