import { Suspense, lazy, useRef, useState } from 'react';
import { ArrowDown } from 'lucide-react';
import { siteConfig } from '../config/siteConfig.js';
import { cars, CATEGORIES } from '../data/cars.js';
import { useScrollAnimation } from '../hooks/useScrollAnimation.js';
import { anchorClick } from '../utils/scroll.js';
import SceneFallback from './SceneFallback.jsx';

// Komponen 3D (three.js) dimuat terpisah agar bundel awal tetap ringan.
const Car3DScene = lazy(() => import('./Car3DScene.jsx'));

const MODE_LABEL = {
  glb: '3D model aktif',
  procedural: '3D placeholder — letakkan file .glb di /public/models/car.glb',
  fallback: 'Mode gambar (3D tidak tersedia)',
};

export default function Hero() {
  const ref = useRef(null);
  const progressRef = useRef({ p: 0 });
  const [mode, setMode] = useState('checking');
  const hero = cars[0];

  useScrollAnimation(ref, ({ scope, gsap }) => {
    gsap.timeline({
      scrollTrigger: {
        trigger: scope,
        start: 'top top',
        end: 'bottom top',
        scrub: 0.6,
        onUpdate: (self) => {
          progressRef.current.p = self.progress;
        },
      },
    })
      .to('.hero__title', { xPercent: -6, yPercent: -10, ease: 'none' }, 0)
      .to('.hero__content', { yPercent: -30, opacity: 0.2, ease: 'none' }, 0);
    // Mode gambar: beri efek depth/parallax pada wrapper. Mode 3D digerakkan langsung oleh progressRef.
    if (mode === 'fallback') {
      gsap.to('.hero__scene', {
        yPercent: 8,
        scale: 0.92,
        ease: 'none',
        scrollTrigger: { trigger: scope, start: 'top top', end: 'bottom top', scrub: 0.6 },
      });
    }
    return () => {
      progressRef.current.p = 0;
    };
  }, [mode]);

  const fallbackNode = <SceneFallback src={hero.image} alt={`Ilustrasi placeholder ${hero.name}`} />;

  return (
    <section id="home" className="hero" ref={ref} aria-labelledby="hero-title">
      <div className="hero__glow" aria-hidden="true" />
      <div className="hero__lines" aria-hidden="true" />

      <h1 id="hero-title" className="hero__title">
        <span>DRIVE</span>
        <span className="accent">YOUR</span>
        <span>FUTURE</span>
      </h1>

      <div className="hero__scene">
        <Suspense fallback={fallbackNode}>
          <Car3DScene
            modelUrl={siteConfig.model3D.url}
            fallbackSrc={hero.image}
            fallbackAlt={`Ilustrasi placeholder ${hero.name}`}
            progressRef={progressRef}
            accent={siteConfig.model3D.accent}
            bodyColor={siteConfig.model3D.bodyColor}
            enabled={siteConfig.features.show3D}
            onModeChange={setMode}
          />
        </Suspense>
      </div>

      <div className="hero__content">
        <p className="hero__label">THE NEXT GENERATION OF DRIVING</p>
        <p className="hero__sub">Discover your next car. Experience the drive before you decide.</p>
        <div className="hero__buttons">
          <a href="#explore" className="btn btn--primary" onClick={(e) => anchorClick(e, 'explore')}>
            EXPLORE COLLECTION
          </a>
          <a href="#booking" className="btn btn--outline" onClick={(e) => anchorClick(e, 'booking')}>
            BOOK TEST DRIVE
          </a>
        </div>
      </div>

      <div className="hero__meta">
        <ul className="hero__chips" aria-label="Kategori kendaraan">
          {CATEGORIES.filter((c) => c.value !== 'all').map((c) => (
            <li key={c.value}>{c.label}</li>
          ))}
        </ul>
        {mode !== 'checking' && <p className="hero__mode">{MODE_LABEL[mode]}</p>}
      </div>

      <a href="#experience" className="hero__scroll" onClick={(e) => anchorClick(e, 'experience')} aria-label="Scroll ke bawah">
        <span>SCROLL</span>
        <ArrowDown size={16} aria-hidden="true" />
      </a>
    </section>
  );
}
