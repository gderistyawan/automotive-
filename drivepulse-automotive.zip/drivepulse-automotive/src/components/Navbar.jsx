import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { siteConfig } from '../config/siteConfig.js';
import { anchorClick, scrollToId } from '../utils/scroll.js';
import { waMessages } from '../utils/whatsapp.js';
import WhatsAppButton from './WhatsAppButton.jsx';

const LINKS = [
  { id: 'home', label: 'Home' },
  { id: 'explore', label: 'Explore Cars' },
  { id: 'experience', label: 'Our Experience' },
  { id: 'simulator', label: 'Credit Simulator' },
  { id: 'contact', label: 'Contact' },
];

function useActiveSection(ids) {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    const els = ids.map((id) => document.getElementById(id)).filter(Boolean);
    if (!('IntersectionObserver' in window) || els.length === 0) return undefined;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) setActive(en.target.id);
        });
      },
      { rootMargin: '-45% 0px -50% 0px', threshold: 0 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [ids]);
  return active;
}

const IDS = LINKS.map((l) => l.id);

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const active = useActiveSection(IDS);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  const go = (e, id) => {
    setOpen(false);
    anchorClick(e, id);
  };

  return (
    <header className={`navbar ${scrolled ? 'navbar--solid' : ''}`}>
      <div className="navbar__inner container">
        <a href="#home" className="brand" onClick={(e) => go(e, 'home')} aria-label={`${siteConfig.name} — ke atas`}>
          {siteConfig.logo?.src && <img src={siteConfig.logo.src} alt="" width="32" height="32" />}
          <span className="brand__text">
            {siteConfig.shortName}
            <small>AUTOMOTIVE</small>
          </span>
        </a>

        <nav className="navbar__links" aria-label="Navigasi utama">
          {LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              className={active === l.id ? 'is-active' : ''}
              aria-current={active === l.id ? 'true' : undefined}
              onClick={(e) => go(e, l.id)}
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="navbar__actions">
          <span className="navbar__wa">
            <WhatsAppButton message={waMessages.general()} label="WHATSAPP" variant="ghost" />
          </span>
          <a href="#booking" className="btn btn--primary navbar__cta" onClick={(e) => go(e, 'booking')}>
            BOOK TEST DRIVE
          </a>
          <button
            type="button"
            className="navbar__toggle"
            aria-label={open ? 'Tutup menu' : 'Buka menu'}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            id="mobile-menu"
            className="mobile-menu"
            aria-label="Menu mobile"
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.22 }}
          >
            {LINKS.map((l, i) => (
              <motion.a
                key={l.id}
                href={`#${l.id}`}
                className={active === l.id ? 'is-active' : ''}
                onClick={(e) => go(e, l.id)}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.04 * i }}
              >
                {l.label}
              </motion.a>
            ))}
            <a href="#booking" className="btn btn--primary" onClick={(e) => go(e, 'booking')}>
              BOOK TEST DRIVE
            </a>
            <WhatsAppButton message={waMessages.general()} label="WHATSAPP SALES" />
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}

export { scrollToId };
