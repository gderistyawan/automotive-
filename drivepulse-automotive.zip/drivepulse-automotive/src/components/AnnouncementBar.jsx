import { siteConfig } from '../config/siteConfig.js';

export default function AnnouncementBar() {
  if (!siteConfig.announcement) return null;
  return (
    <div className="announcement" role="note">
      <p>{siteConfig.announcement}</p>
    </div>
  );
}
