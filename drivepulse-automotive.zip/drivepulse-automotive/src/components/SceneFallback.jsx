/** Gambar pengganti saat model 3D belum siap / WebGL tidak tersedia. Bukan model 3D interaktif. */
export default function SceneFallback({ src, alt = 'Ilustrasi kendaraan', className = '' }) {
  return (
    <div className={`scene-fallback ${className}`}>
      <img src={src} alt={alt} data-parallax width="800" height="360" decoding="async" />
    </div>
  );
}
