import { Component, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { ContactShadows, Environment, Html, Lightformer, RoundedBox, useGLTF, useProgress } from '@react-three/drei';
import * as THREE from 'three';
import SceneFallback from './SceneFallback.jsx';

/* ------------------------------------------------------------------ helpers */

function supportsWebGL() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch {
    return false;
  }
}

/** Vite dev server & Vercel bisa mengembalikan index.html (200) untuk path yang tidak ada,
 *  jadi selain res.ok kita periksa juga content-type bukan text/html. */
async function modelExists(url, signal) {
  try {
    const res = await fetch(url, { method: 'HEAD', signal });
    const type = res.headers.get('content-type') || '';
    return res.ok && !type.includes('text/html');
  } catch {
    return false;
  }
}

class SceneErrorBoundary extends Component {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error) {
    console.warn('[Car3DScene] Gagal merender 3D, memakai gambar fallback:', error?.message);
    this.props.onError?.();
  }
  render() {
    return this.state.hasError ? this.props.fallback : this.props.children;
  }
}

/* ------------------------------------------------------------------ 3D parts */

function Loader() {
  const { progress } = useProgress();
  return (
    <Html center>
      <div className="scene-loader" role="status">
        Memuat model 3D… {Math.round(progress)}%
      </div>
    </Html>
  );
}

/** Model placeholder prosedural (BUKAN model kendaraan nyata). Depan mobil = +X. */
function ProceduralCar({ bodyColor, accent }) {
  const paint = <meshStandardMaterial color={bodyColor} metalness={0.85} roughness={0.28} envMapIntensity={1.2} />;
  const glass = <meshStandardMaterial color="#0b0d12" metalness={0.9} roughness={0.08} envMapIntensity={1.4} />;
  const wheels = [
    [1.35, 0.38, 0.92],
    [1.35, 0.38, -0.92],
    [-1.35, 0.38, 0.92],
    [-1.35, 0.38, -0.92],
  ];
  return (
    <group>
      <RoundedBox args={[4.3, 0.62, 1.8]} radius={0.22} smoothness={4} position={[0, 0.62, 0]} castShadow>
        {paint}
      </RoundedBox>
      <RoundedBox args={[2.2, 0.56, 1.55]} radius={0.24} smoothness={4} position={[-0.25, 1.17, 0]} castShadow>
        {glass}
      </RoundedBox>
      <RoundedBox args={[1.2, 0.08, 1.7]} radius={0.04} position={[1.2, 0.98, 0]}>
        {paint}
      </RoundedBox>
      {wheels.map((p, i) => (
        <group key={i} position={p} rotation={[Math.PI / 2, 0, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.38, 0.38, 0.32, 32]} />
            <meshStandardMaterial color="#0a0a0c" roughness={0.7} metalness={0.2} />
          </mesh>
          <mesh position={[0, p[2] > 0 ? 0.17 : -0.17, 0]}>
            <cylinderGeometry args={[0.22, 0.22, 0.02, 32]} />
            <meshStandardMaterial color={accent} emissive={accent} emissiveIntensity={0.6} />
          </mesh>
        </group>
      ))}
      <mesh position={[2.16, 0.7, 0.55]}>
        <boxGeometry args={[0.04, 0.1, 0.4]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
      <mesh position={[2.16, 0.7, -0.55]}>
        <boxGeometry args={[0.04, 0.1, 0.4]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
      <mesh position={[-2.16, 0.72, 0]}>
        <boxGeometry args={[0.04, 0.08, 1.5]} />
        <meshBasicMaterial color={accent} />
      </mesh>
    </group>
  );
}

function GLBModel({ url }) {
  const { scene } = useGLTF(url);
  const { object, scale, offset } = useMemo(() => {
    const clone = scene.clone(true);
    clone.traverse((o) => {
      if (o.isMesh) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
    const box = new THREE.Box3().setFromObject(clone);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const s = 4.3 / Math.max(size.x, size.z, 0.0001);
    return { object: clone, scale: s, offset: [-center.x, -box.min.y, -center.z] };
  }, [scene]);
  return (
    <group scale={scale}>
      <primitive object={object} position={offset} />
    </group>
  );
}

/** Menggerakkan mobil: posisi/skala mengikuti progress scroll (progressRef.current.p) + parallax pointer. */
function Rig({ progressRef, pointer, reduced, children }) {
  const outer = useRef();
  const inner = useRef();
  const { viewport } = useThree();

  useFrame((state, dt) => {
    const p = progressRef?.current?.p ?? 0;
    const wide = viewport.width > 6.5;
    const fit = THREE.MathUtils.clamp(viewport.width / 7.4, 0.5, 1.15);
    const tx = wide ? THREE.MathUtils.lerp(1.0, -1.7, p) : 0;
    const ty = THREE.MathUtils.lerp(0, -0.25, p);
    const s = fit * THREE.MathUtils.lerp(1, 0.78, p);
    const sway = reduced ? 0 : Math.sin(state.clock.elapsedTime * 0.35) * 0.1;
    const ry = -0.5 + p * 1.5 + sway + (reduced ? 0 : pointer.current.x * 0.3);
    const rx = reduced ? 0 : pointer.current.y * -0.04;

    const o = outer.current;
    const i = inner.current;
    if (!o || !i) return;
    o.position.x = THREE.MathUtils.damp(o.position.x, tx, 4, dt);
    o.position.y = THREE.MathUtils.damp(o.position.y, ty, 4, dt);
    const ns = THREE.MathUtils.damp(o.scale.x, s, 4, dt);
    o.scale.setScalar(ns);
    i.rotation.y = THREE.MathUtils.damp(i.rotation.y, ry, 4, dt);
    i.rotation.x = THREE.MathUtils.damp(i.rotation.x, rx, 4, dt);
  });

  return (
    <group ref={outer}>
      <group ref={inner}>{children}</group>
    </group>
  );
}

function Studio({ accent, small }) {
  return (
    <>
      <ambientLight intensity={0.35} />
      <directionalLight position={[5, 7, 4]} intensity={2.2} castShadow={!small} shadow-mapSize={[1024, 1024]} />
      <directionalLight position={[-6, 3, -5]} intensity={2.4} color={accent} />
      <Environment resolution={256}>
        <Lightformer form="rect" intensity={2.2} position={[0, 5, -6]} scale={[12, 2, 1]} />
        <Lightformer form="rect" intensity={1.4} position={[-6, 1, 0]} rotation-y={Math.PI / 2} scale={[8, 2, 1]} />
        <Lightformer form="rect" intensity={1.0} position={[6, 1, 2]} rotation-y={-Math.PI / 2} scale={[8, 2, 1]} />
        <Lightformer form="ring" color={accent} intensity={3} position={[3, 2, -4]} scale={3} />
      </Environment>
    </>
  );
}

/* ------------------------------------------------------------------ main */

/**
 * Props:
 *  modelUrl      — path .glb/.gltf (opsional). Jika tidak ada file → model placeholder prosedural.
 *  fallbackSrc   — gambar untuk fallback (WebGL tidak ada / error / 3D dimatikan).
 *  progressRef   — ref { current: { p: 0..1 } } diisi ScrollTrigger.
 *  onModeChange  — 'glb' | 'procedural' | 'fallback'
 */
export default function Car3DScene({
  modelUrl,
  fallbackSrc,
  fallbackAlt = 'Ilustrasi kendaraan',
  progressRef,
  accent = '#C8FA50',
  bodyColor = '#2b2f38',
  enabled = true,
  onModeChange,
  className = '',
}) {
  const wrapRef = useRef(null);
  const pointer = useRef({ x: 0, y: 0 });
  const [inView, setInView] = useState(true);
  const [failed, setFailed] = useState(false);
  const [glbOk, setGlbOk] = useState(null); // null = sedang memeriksa

  const webgl = useMemo(() => supportsWebGL(), []);
  const small = useMemo(() => window.matchMedia('(max-width: 768px)').matches, []);
  const reduced = useMemo(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches, []);

  useEffect(() => {
    if (!modelUrl) {
      setGlbOk(false);
      return undefined;
    }
    const ctrl = new AbortController();
    modelExists(modelUrl, ctrl.signal).then((ok) => !ctrl.signal.aborted && setGlbOk(ok));
    return () => ctrl.abort();
  }, [modelUrl]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el || !('IntersectionObserver' in window)) return undefined;
    const io = new IntersectionObserver(([en]) => setInView(en.isIntersecting), { threshold: 0 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (reduced || small || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return undefined;
    const onMove = (e) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => window.removeEventListener('pointermove', onMove);
  }, [reduced, small]);

  const mode = !enabled || !webgl || failed ? 'fallback' : glbOk === null ? 'checking' : glbOk ? 'glb' : 'procedural';

  useEffect(() => {
    if (mode !== 'checking') onModeChange?.(mode);
  }, [mode, onModeChange]);

  const fallback = <SceneFallback src={fallbackSrc} alt={fallbackAlt} />;

  return (
    <div ref={wrapRef} className={`scene ${className}`}>
      {mode === 'fallback' || mode === 'checking' ? (
        fallback
      ) : (
        <SceneErrorBoundary fallback={fallback} onError={() => setFailed(true)}>
          <Canvas
            shadows={!small}
            dpr={small ? [1, 1.5] : [1, 2]}
            camera={{ position: [5.2, 1.7, 6.4], fov: 34 }}
            gl={{ antialias: !small, alpha: true, powerPreference: 'high-performance' }}
            frameloop={inView ? 'always' : 'never'}
            onCreated={({ gl }) => {
              gl.toneMapping = THREE.ACESFilmicToneMapping;
              gl.toneMappingExposure = 1.05;
              gl.domElement.addEventListener('webglcontextlost', (e) => {
                e.preventDefault();
                setFailed(true);
              });
            }}
            aria-label="Tampilan 3D kendaraan"
          >
            <Studio accent={accent} small={small} />
            <Rig progressRef={progressRef} pointer={pointer} reduced={reduced}>
              <ContactShadows position={[0, 0.002, 0]} opacity={0.65} scale={11} blur={2.4} far={3} resolution={small ? 256 : 512} />
              <mesh rotation-x={-Math.PI / 2} position={[0, 0.01, 0]}>
                <ringGeometry args={[2.95, 3.0, 96]} />
                <meshBasicMaterial color={accent} transparent opacity={0.55} />
              </mesh>
              <Suspense fallback={<Loader />}>
                {mode === 'glb' ? <GLBModel url={modelUrl} /> : <ProceduralCar bodyColor={bodyColor} accent={accent} />}
              </Suspense>
            </Rig>
          </Canvas>
        </SceneErrorBoundary>
      )}
    </div>
  );
}
