import { MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl } from '../utils/whatsapp.js';

/**
 * Tautan WhatsApp dengan pesan terisi. `floating` = tombol bulat di pojok layar.
 * Nomor diatur di satu tempat: src/config/siteConfig.js (atau VITE_WHATSAPP_NUMBER).
 */
export default function WhatsAppButton({ message, label = 'WHATSAPP SALES', variant = 'outline', floating = false, className = '', icon = true }) {
  const href = buildWhatsAppUrl(message);
  if (floating) {
    return (
      <a className="wa-float" href={href} target="_blank" rel="noopener noreferrer" aria-label="Chat WhatsApp sales (membuka tab baru)">
        <MessageCircle size={26} aria-hidden="true" />
      </a>
    );
  }
  return (
    <a className={`btn btn--${variant} ${className}`} href={href} target="_blank" rel="noopener noreferrer">
      {icon && <MessageCircle size={16} aria-hidden="true" />}
      {label}
      <span className="sr-only"> (membuka WhatsApp di tab baru)</span>
    </a>
  );
}
