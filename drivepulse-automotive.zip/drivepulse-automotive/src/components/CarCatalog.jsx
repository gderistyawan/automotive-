import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CATEGORIES, cars } from '../data/cars.js';
import CarCard from './CarCard.jsx';

export default function CarCatalog({ onDetails, onSimulate }) {
  const [filter, setFilter] = useState('all');
  const visible = useMemo(() => (filter === 'all' ? cars : cars.filter((c) => c.category === filter)), [filter]);

  return (
    <section id="explore" className="section catalog" aria-labelledby="catalog-title">
      <div className="container">
        <header className="section__head">
          <p className="eyebrow">THE COLLECTION</p>
          <h2 id="catalog-title" className="section__title">
            EXPLORE <span className="accent">CARS</span>
          </h2>
          <p className="section__lead">
            Katalog berikut berisi <strong>data demo</strong> sebagai contoh tampilan. Ganti dengan data dealer yang sudah dikonfirmasi di{' '}
            <code>src/data/cars.js</code>.
          </p>
        </header>

        <div className="filters" role="group" aria-label="Filter kategori kendaraan">
          {CATEGORIES.map((c) => (
            <button
              key={c.value}
              type="button"
              className={`chip ${filter === c.value ? 'is-active' : ''}`}
              aria-pressed={filter === c.value}
              onClick={() => setFilter(c.value)}
            >
              {c.label}
            </button>
          ))}
        </div>

        <p className="sr-only" aria-live="polite">
          Menampilkan {visible.length} kendaraan
        </p>

        <motion.div className="catalog__grid" layout>
          <AnimatePresence mode="popLayout">
            {visible.map((car) => (
              <motion.div
                key={car.id}
                layout
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.28 }}
              >
                <CarCard car={car} onDetails={onDetails} onSimulate={onSimulate} />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {visible.length === 0 && <p className="empty">Belum ada kendaraan pada kategori ini. Pilih kategori lain atau hubungi sales.</p>}
      </div>
    </section>
  );
}
