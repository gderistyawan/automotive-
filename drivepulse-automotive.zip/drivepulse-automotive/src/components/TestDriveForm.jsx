import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, AlertTriangle } from 'lucide-react';
import { siteConfig } from '../config/siteConfig.js';
import { cars, getCarById } from '../data/cars.js';
import { normalizeIndonesianPhone, submitBooking, todayISO, validateBooking } from '../utils/booking.js';
import { waMessages } from '../utils/whatsapp.js';
import WhatsAppButton from './WhatsAppButton.jsx';

const EMPTY = { fullName: '', whatsapp: '', vehicle: '', date: '', time: '', branch: '', notes: '', consent: false };

export default function TestDriveForm({ presetCarId }) {
  const [values, setValues] = useState({ ...EMPTY, branch: siteConfig.branches.length === 1 ? siteConfig.branches[0].id : '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | submitting | whatsapp | saved | error
  const [summary, setSummary] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (presetCarId) setValues((v) => ({ ...v, vehicle: presetCarId }));
  }, [presetCarId]);

  const set = (name) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setValues((v) => ({ ...v, [name]: value }));
    if (errors[name]) setErrors((er) => ({ ...er, [name]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const errs = validateBooking(values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      const first = Object.keys(errs)[0];
      document.getElementById(`td-${first}`)?.focus();
      return;
    }

    const car = getCarById(values.vehicle);
    const branch = siteConfig.branches.find((b) => b.id === values.branch);
    const data = {
      fullName: values.fullName.trim(),
      whatsapp: normalizeIndonesianPhone(values.whatsapp),
      vehicleLabel: car ? `${car.brand} ${car.name} ${car.year}` : 'Belum yakin / minta rekomendasi sales',
      date: values.date,
      time: values.time,
      branchLabel: branch?.name || values.branch,
      notes: values.notes.trim(),
    };

    setStatus('submitting');
    setErrorMsg('');
    try {
      const { channel } = await submitBooking({
        full_name: data.fullName,
        whatsapp: data.whatsapp,
        vehicle: car ? car.id : null,
        vehicle_label: data.vehicleLabel,
        preferred_date: data.date,
        preferred_time: data.time,
        branch: values.branch,
        notes: data.notes || null,
        consent: true,
        created_via: 'website',
      });
      setSummary(data);
      setStatus(channel === 'whatsapp' ? 'whatsapp' : 'saved');
    } catch (err) {
      setErrorMsg(err.message || 'Terjadi kesalahan.');
      setSummary(data);
      setStatus('error');
    }
  };

  const reset = () => {
    setValues({ ...EMPTY, branch: siteConfig.branches.length === 1 ? siteConfig.branches[0].id : '' });
    setErrors({});
    setSummary(null);
    setStatus('idle');
  };

  const field = (name) => ({
    id: `td-${name}`,
    value: values[name],
    onChange: set(name),
    'aria-invalid': !!errors[name],
    'aria-describedby': errors[name] ? `td-${name}-err` : undefined,
  });
  const err = (name) =>
    errors[name] ? (
      <small id={`td-${name}-err`} className="error" role="alert">
        {errors[name]}
      </small>
    ) : null;

  const showForm = status === 'idle' || status === 'submitting';

  return (
    <section id="contact" className="section contact" aria-labelledby="contact-title">
      <div className="container contact__grid">
        <header className="section__head contact__head">
          <p className="eyebrow">TEST DRIVE</p>
          <h2 id="contact-title" className="section__title">
            BOOK YOUR <span className="accent">TEST DRIVE</span>
          </h2>
          <p className="section__lead">
            Isi form berikut untuk meminta jadwal test drive. Permintaan baru dianggap <strong>terkonfirmasi setelah sales menghubungi Anda</strong>.
          </p>
          {siteConfig.contact.phone && <p>Telepon: {siteConfig.contact.phone}</p>}
          {siteConfig.contact.hours && <p>Jam operasional: {siteConfig.contact.hours}</p>}
          <WhatsAppButton message={waMessages.general()} label="CONTACT SALES" variant="outline" />
        </header>

        <div id="booking" className="booking">
          <AnimatePresence mode="wait">
            {showForm ? (
              <motion.form key="form" onSubmit={onSubmit} noValidate className="form" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
                <div className="field-row">
                  <div className={`field ${errors.fullName ? 'field--error' : ''}`}>
                    <label htmlFor="td-fullName">Nama lengkap</label>
                    <input type="text" autoComplete="name" {...field('fullName')} />
                    {err('fullName')}
                  </div>
                  <div className={`field ${errors.whatsapp ? 'field--error' : ''}`}>
                    <label htmlFor="td-whatsapp">Nomor WhatsApp</label>
                    <input type="tel" inputMode="tel" autoComplete="tel" placeholder="0812xxxxxxxx" {...field('whatsapp')} />
                    {err('whatsapp')}
                  </div>
                </div>

                <div className={`field ${errors.vehicle ? 'field--error' : ''}`}>
                  <label htmlFor="td-vehicle">Kendaraan</label>
                  <select {...field('vehicle')}>
                    <option value="">Pilih kendaraan…</option>
                    {cars.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.brand} {c.name} {c.year}
                        {c.isDemo ? ' (demo)' : ''}
                      </option>
                    ))}
                    <option value="undecided">Belum yakin — minta rekomendasi sales</option>
                  </select>
                  {err('vehicle')}
                </div>

                <div className="field-row">
                  <div className={`field ${errors.date ? 'field--error' : ''}`}>
                    <label htmlFor="td-date">Tanggal diinginkan</label>
                    <input type="date" min={todayISO()} {...field('date')} />
                    {err('date')}
                  </div>
                  <div className={`field ${errors.time ? 'field--error' : ''}`}>
                    <label htmlFor="td-time">Waktu diinginkan</label>
                    <select {...field('time')}>
                      <option value="">Pilih waktu…</option>
                      {siteConfig.booking.timeSlots.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                    {err('time')}
                  </div>
                </div>

                <div className={`field ${errors.branch ? 'field--error' : ''}`}>
                  <label htmlFor="td-branch">Lokasi / cabang</label>
                  <select {...field('branch')}>
                    <option value="">Pilih lokasi…</option>
                    {siteConfig.branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                  {err('branch')}
                </div>

                <div className="field">
                  <label htmlFor="td-notes">Catatan tambahan (opsional)</label>
                  <textarea rows="3" maxLength={500} {...field('notes')} />
                </div>

                <div className={`field field--check ${errors.consent ? 'field--error' : ''}`}>
                  <label className="check">
                    <input
                      id="td-consent"
                      type="checkbox"
                      checked={values.consent}
                      onChange={set('consent')}
                      aria-invalid={!!errors.consent}
                      aria-describedby={errors.consent ? 'td-consent-err' : undefined}
                    />
                    <span>Saya setuju data saya digunakan untuk menindaklanjuti permintaan test drive ini.</span>
                  </label>
                  {err('consent')}
                </div>

                <button type="submit" className="btn btn--primary btn--lg" disabled={status === 'submitting'}>
                  {status === 'submitting' ? 'MENGIRIM…' : 'REQUEST TEST DRIVE'}
                </button>
              </motion.form>
            ) : (
              <motion.div key="result" className="result" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} role="status" aria-live="polite">
                {status === 'error' ? (
                  <h3 className="result__title result__title--error">
                    <AlertTriangle size={22} aria-hidden="true" /> Permintaan belum tersimpan
                  </h3>
                ) : (
                  <h3 className="result__title">
                    <CheckCircle2 size={22} aria-hidden="true" /> {status === 'saved' ? 'Permintaan tersimpan' : 'Satu langkah lagi: kirim via WhatsApp'}
                  </h3>
                )}

                {status === 'whatsapp' && (
                  <p>Permintaan Anda <strong>belum terkirim</strong>. Klik tombol di bawah untuk membuka WhatsApp dengan pesan yang sudah terisi, lalu kirim ke sales dan tunggu konfirmasi.</p>
                )}
                {status === 'saved' && <p>Permintaan Anda sudah tercatat di sistem kami. Jadwal <strong>belum dikonfirmasi</strong> — tunggu sales menghubungi Anda.</p>}
                {status === 'error' && <p>{errorMsg} Anda tetap dapat mengirim permintaan lewat WhatsApp.</p>}

                {summary && (
                  <dl className="result__summary">
                    <div><dt>Nama</dt><dd>{summary.fullName}</dd></div>
                    <div><dt>WhatsApp</dt><dd>{summary.whatsapp}</dd></div>
                    <div><dt>Kendaraan</dt><dd>{summary.vehicleLabel}</dd></div>
                    <div><dt>Jadwal</dt><dd>{summary.date} · {summary.time}</dd></div>
                    <div><dt>Lokasi</dt><dd>{summary.branchLabel}</dd></div>
                    {summary.notes && <div><dt>Catatan</dt><dd>{summary.notes}</dd></div>}
                  </dl>
                )}

                <div className="result__actions">
                  {summary && <WhatsAppButton variant="primary" label="KIRIM VIA WHATSAPP" message={waMessages.booking(summary)} />}
                  <button type="button" className="btn btn--ghost" onClick={reset}>
                    {status === 'error' ? 'COBA LAGI' : 'BUAT PERMINTAAN BARU'}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
