import { useMemo } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Fuel, Gauge } from 'lucide-react';
import { siteConfig } from '../config/siteConfig.js';
import { formatIDR } from '../utils/format.js';
import { waMessages } from '../utils/whatsapp.js';
import WhatsAppButton from './WhatsAppButton.jsx';

export function PriceLabel({ car }) {
  if (!siteConfig.features.showPrices || car.price == null) {
    return <span className="price price--none">Hubungi sales untuk harga</span>;
  }
  return (
    <span className="price">
      <span className="price__label">Harga OTR</span>
      <strong>{formatIDR(car.price)}</strong>
      {car.isDemo && siteConfig.features.demoBadges && <span className="badge badge--demo">HARGA DEMO</span>}
    </span>
  );
}

export default function CarCard({ car, onDetails, onSimulate }) {
  const canTilt = useMemo(
    () =>
      typeof window !== 'undefined' &&
      window.matchMedia('(hover: hover) and (pointer: fine)').matches &&
      !window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    []
  );

  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rotateX = useSpring(useTransform(my, [-0.5, 0.5], [7, -7]), { stiffness: 220, damping: 22 });
  const rotateY = useSpring(useTransform(mx, [-0.5, 0.5], [-9, 9]), { stiffness: 220, damping: 22 });
  const imgX = useSpring(useTransform(mx, [-0.5, 0.5], [-10, 10]), { stiffness: 160, damping: 20 });

  const onMove = (e) => {
    if (!canTilt) return;
    const r = e.currentTarget.getBoundingClientRect();
    mx.set((e.clientX - r.left) / r.width - 0.5);
    my.set((e.clientY - r.top) / r.height - 0.5);
  };
  const onLeave = () => {
    mx.set(0);
    my.set(0);
  };

  return (
    <motion.article
      className="car-card"
      style={canTilt ? { rotateX, rotateY, transformPerspective: 900 } : undefined}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      whileHover={canTilt ? { y: -6 } : undefined}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
    >
      <div className="car-card__media">
        <motion.img
          src={car.image}
          alt={`${car.brand} ${car.name} ${car.year}${car.isDemo ? ' (ilustrasi placeholder)' : ''}`}
          loading="lazy"
          decoding="async"
          width="800"
          height="360"
          style={canTilt ? { x: imgX } : undefined}
        />
        <span className="badge badge--cat">{car.category}</span>
        {car.isDemo && siteConfig.features.demoBadges && <span className="badge badge--demo badge--corner">DATA DEMO</span>}
      </div>

      <div className="car-card__body">
        <p className="car-card__brand">
          {car.brand} · {car.year}
        </p>
        <h3 className="car-card__name">{car.name}</h3>
        <ul className="car-card__tags">
          {car.fuel && (
            <li>
              <Fuel size={14} aria-hidden="true" /> {car.fuel}
            </li>
          )}
          {car.drivetrain && (
            <li>
              <Gauge size={14} aria-hidden="true" /> {car.drivetrain}
            </li>
          )}
        </ul>
        <PriceLabel car={car} />
        <div className="car-card__actions">
          <button type="button" className="btn btn--primary btn--sm" onClick={() => onDetails(car)}>
            VIEW DETAILS
          </button>
          <button type="button" className="btn btn--outline btn--sm" onClick={() => onSimulate(car)}>
            SIMULATE CREDIT
          </button>
          <WhatsAppButton message={waMessages.car(car)} label="WHATSAPP SALES" variant="ghost" className="btn--sm" />
        </div>
      </div>
    </motion.article>
  );
}
