import { useRef } from 'react';
import { featuredCars } from '../data/cars.js';
import { useScrollAnimation } from '../hooks/useScrollAnimation.js';
import { waMessages } from '../utils/whatsapp.js';
import CarCard from './CarCard.jsx';
import WhatsAppButton from './WhatsAppButton.jsx';

const PANELS = [
  { mode: 'ltr', kicker: 'Kiri ke kanan', title: 'MOVE WITH THE SCROLL', bg: 'FORWARD' },
  { mode: 'rtl', kicker: 'Kanan ke kiri', title: 'CHANGE OF DIRECTION', bg: 'REVERSE' },
  { mode: 'zoom', kicker: 'Mendekat ke kamera', title: 'CLOSER LOOK', bg: 'DETAIL' },
  { mode: 'counter', kicker: 'Teks melawan arah mobil', title: 'OPPOSITE FORCES', bg: 'COUNTER' },
];

export default function CarShowcase({ onDetails, onSimulate }) {
  const ref = useRef(null);

  useScrollAnimation(
    ref,
    ({ scope, gsap, mobile }) => {
      const amp = mobile ? '30vw' : '42vw';

      gsap.utils.toArray('.sc-panel', scope).forEach((panel) => {
        const mode = panel.dataset.mode;
        const car = panel.querySelector('.sc-car');
        const bg = panel.querySelector('.sc-bg-text');
        const bar = panel.querySelector('.sc-progress span');

        // scrub: animasi terikat posisi scroll → scroll naik = animasi mundur secara alami.
        const tl = gsap.timeline({
          defaults: { ease: 'none' },
          scrollTrigger: { trigger: panel, start: 'top top', end: 'bottom bottom', scrub: 0.8, invalidateOnRefresh: true },
        });

        if (mode === 'ltr') {
          tl.fromTo(car, { x: `-${amp}` }, { x: amp, duration: 1 }, 0).fromTo(bg, { x: '8vw' }, { x: '-8vw', duration: 1 }, 0);
        } else if (mode === 'rtl') {
          tl.fromTo(car, { x: amp }, { x: `-${amp}`, duration: 1 }, 0).fromTo(bg, { x: '-8vw' }, { x: '8vw', duration: 1 }, 0);
        } else if (mode === 'zoom') {
          tl.fromTo(car, { scale: 0.55 }, { scale: 1.45, ease: 'power2.inOut', duration: 0.5 }, 0)
            .to(car, { scale: 0.7, ease: 'power2.in', duration: 0.5 }, 0.5)
            .fromTo(bg, { scale: 0.9, opacity: 0.5 }, { scale: 1.2, opacity: 1, duration: 1 }, 0);
        } else if (mode === 'counter') {
          tl.fromTo(car, { x: `-${amp}` }, { x: amp, duration: 1 }, 0).fromTo(bg, { x: '45vw' }, { x: '-45vw', duration: 1 }, 0);
        }
        if (bar) tl.fromTo(bar, { scaleX: 0 }, { scaleX: 1, duration: 1 }, 0);
      });

      // Kartu masuk bergantian dari kiri dan kanan, juga terikat scroll.
      gsap.utils.toArray('.sc-card-wrap', scope).forEach((wrap) => {
        const dir = Number(wrap.dataset.dir);
        gsap.fromTo(
          wrap,
          { xPercent: dir * 115, opacity: 0 },
          {
            xPercent: 0,
            opacity: 1,
            ease: 'power2.out',
            scrollTrigger: { trigger: wrap, start: 'top 92%', end: 'top 50%', scrub: true },
          }
        );
      });
      return undefined;
    },
    []
  );

  return (
    <section id="experience" className="showcase" ref={ref} aria-label="Showcase kendaraan">
      {PANELS.map((p, i) => {
        const car = featuredCars[i % featuredCars.length];
        return (
          <div className="sc-panel" data-mode={p.mode} key={p.mode}>
            <div className="sc-stage">
              <div className="sc-bg-text" aria-hidden="true">
                {p.bg}
              </div>
              <img
                className="sc-car"
                src={car.image}
                alt={`${car.brand} ${car.name} (ilustrasi placeholder)`}
                loading="lazy"
                decoding="async"
                width="800"
                height="360"
              />
              <div className="sc-info">
                <p className="eyebrow">{p.kicker}</p>
                <h2 className="sc-title">{p.title}</h2>
                <p className="sc-car-name">
                  {car.brand} {car.name} — {car.category}
                </p>
                <div className="sc-actions">
                  <button type="button" className="btn btn--primary btn--sm" onClick={() => onDetails(car)}>
                    VIEW DETAILS
                  </button>
                  <WhatsAppButton message={waMessages.car(car)} label="ASK SALES" variant="ghost" className="btn--sm" />
                </div>
              </div>
              <div className="sc-progress" aria-hidden="true">
                <span />
              </div>
            </div>
          </div>
        );
      })}

      <div className="sc-cards">
        <div className="container">
          <h2 className="section__title section__title--sm">
            FEATURED <span className="accent">LINEUP</span>
          </h2>
          <div className="sc-cards__grid">
            {featuredCars.slice(0, 4).map((car, i) => (
              <div className="sc-card-wrap" data-dir={i % 2 === 0 ? -1 : 1} key={car.id}>
                <CarCard car={car} onDetails={onDetails} onSimulate={onSimulate} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
