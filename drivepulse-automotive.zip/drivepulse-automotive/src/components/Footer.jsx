import { useState } from 'react';
import { Instagram, MapPin, Phone } from 'lucide-react';
import { siteConfig } from '../config/siteConfig.js';
import { anchorClick } from '../utils/scroll.js';
import Modal from './Modal.jsx';

const NAV = [
  { id: 'home', label: 'Home' },
  { id: 'explore', label: 'Explore Cars' },
  { id: 'experience', label: 'Our Experience' },
  { id: 'simulator', label: 'Credit Simulator' },
  { id: 'contact', label: 'Contact' },
];

export default function Footer() {
  const [privacy, setPrivacy] = useState(false);
  const { contact, social, branches } = siteConfig;
  const branchesWithAddress = branches.filter((b) => b.address);
  const socials = [
    { key: 'instagram', label: 'Instagram', url: social.instagram, Icon: Instagram },
    { key: 'facebook', label: 'Facebook', url: social.facebook },
    { key: 'tiktok', label: 'TikTok', url: social.tiktok },
    { key: 'youtube', label: 'YouTube', url: social.youtube },
  ].filter((s) => s.url);

  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div>
          <p className="brand brand--footer">
            {siteConfig.logo?.src && <img src={siteConfig.logo.src} alt="" width="32" height="32" />}
            <span className="brand__text">
              {siteConfig.shortName}
              <small>AUTOMOTIVE</small>
            </span>
          </p>
          <p className="footer__muted">Discover your next car. Experience the drive before you decide.</p>
        </div>

        <nav aria-label="Navigasi footer">
          <h3>Navigasi</h3>
          <ul>
            {NAV.map((n) => (
              <li key={n.id}>
                <a href={`#${n.id}`} onClick={(e) => anchorClick(e, n.id)}>
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3>Kontak</h3>
          <ul>
            {contact.phone && (
              <li>
                <Phone size={14} aria-hidden="true" /> <a href={`tel:${contact.phone.replace(/[^\d+]/g, '')}`}>{contact.phone}</a>
              </li>
            )}
            {contact.email && (
              <li>
                <a href={`mailto:${contact.email}`}>{contact.email}</a>
              </li>
            )}
            {contact.address && (
              <li>
                <MapPin size={14} aria-hidden="true" /> {contact.address}
              </li>
            )}
            {branchesWithAddress.map((b) => (
              <li key={b.id}>
                <MapPin size={14} aria-hidden="true" /> {b.name}: {b.address}
              </li>
            ))}
            {!contact.phone && !contact.email && !contact.address && branchesWithAddress.length === 0 && (
              <li className="footer__muted">Informasi kontak resmi belum dikonfigurasi. Gunakan tombol WhatsApp atau form test drive.</li>
            )}
          </ul>
          {socials.length > 0 && (
            <ul className="footer__social" aria-label="Media sosial">
              {socials.map(({ key, label, url, Icon }) => (
                <li key={key}>
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    {Icon && <Icon size={16} aria-hidden="true" />} {label}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="container footer__bottom">
        <p>
          © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
        </p>
        <button type="button" className="link-btn" onClick={() => setPrivacy(true)}>
          Kebijakan Privasi
        </button>
      </div>

      <Modal open={privacy} onClose={() => setPrivacy(false)} labelledBy="privacy-title">
        <div className="prose">
          <h2 id="privacy-title">Kebijakan Privasi</h2>
          <p className="notice">
            Teks ini adalah <strong>template placeholder</strong>. Ganti dengan kebijakan privasi resmi dealer sebelum website dipublikasikan.
          </p>
          <p>
            Data yang Anda isi pada form test drive (nama, nomor WhatsApp, pilihan kendaraan, jadwal, dan catatan) digunakan hanya untuk menindaklanjuti permintaan Anda oleh tim sales.
          </p>
          <p>
            Jika Anda mengirim permintaan melalui WhatsApp, data tersebut diproses sesuai kebijakan WhatsApp. Simulasi kredit dihitung di perangkat Anda dan tidak dikirim ke server kami.
          </p>
        </div>
      </Modal>
    </footer>
  );
}
