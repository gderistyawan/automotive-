import { cars } from '../data/cars.js';
import { anchorClick } from '../utils/scroll.js';
import { waMessages } from '../utils/whatsapp.js';
import WhatsAppButton from './WhatsAppButton.jsx';

export default function CTASection() {
  const car = cars.find((c) => c.featured) || cars[0];
  return (
    <section className="cta" aria-labelledby="cta-title">
      <div className="cta__glow" aria-hidden="true" />
      <img className="cta__car" src={car.image} alt="" aria-hidden="true" loading="lazy" decoding="async" width="800" height="360" />
      <div className="container cta__inner">
        <h2 id="cta-title" className="cta__title">
          READY FOR YOUR <span className="accent">NEXT DRIVE?</span>
        </h2>
        <p className="cta__sub">Explore the collection and find the vehicle that fits your journey.</p>
        <div className="cta__buttons">
          <a href="#explore" className="btn btn--primary" onClick={(e) => anchorClick(e, 'explore')}>
            EXPLORE CARS
          </a>
          <a href="#booking" className="btn btn--outline" onClick={(e) => anchorClick(e, 'booking')}>
            BOOK TEST DRIVE
          </a>
          <WhatsAppButton message={waMessages.general()} label="CONTACT SALES" variant="ghost" />
        </div>
      </div>
    </section>
  );
}
