import { useEffect, useRef, useState } from 'react';
import { siteConfig } from '../config/siteConfig.js';
import { waMessages } from '../utils/whatsapp.js';
import Modal from './Modal.jsx';
import { PriceLabel } from './CarCard.jsx';
import WhatsAppButton from './WhatsAppButton.jsx';

export default function CarDetails({ car, onClose, onSimulate, onBook }) {
  // Simpan data terakhir agar konten tidak hilang saat animasi keluar modal berjalan.
  const lastCar = useRef(car);
  if (car) lastCar.current = car;
  const shown = car || lastCar.current;

  const [imgIndex, setImgIndex] = useState(0);
  const [colorIndex, setColorIndex] = useState(0);

  useEffect(() => {
    setImgIndex(0);
    setColorIndex(0);
  }, [car?.id]);

  return (
    <Modal open={!!car} onClose={onClose} labelledBy="car-details-title" wide>
      {shown && (
        <div className="details">
          <div className="details__gallery">
            <div className="details__main">
              <img
                src={shown.gallery?.[imgIndex] || shown.image}
                alt={`${shown.brand} ${shown.name}${shown.isDemo ? ' (ilustrasi placeholder)' : ''}`}
                width="800"
                height="360"
                decoding="async"
              />
            </div>
            {shown.gallery?.length > 1 && (
              <div className="details__thumbs" role="group" aria-label="Galeri gambar">
                {shown.gallery.map((src, i) => (
                  <button
                    key={src}
                    type="button"
                    className={i === imgIndex ? 'is-active' : ''}
                    onClick={() => setImgIndex(i)}
                    aria-label={`Gambar ${i + 1}`}
                    aria-pressed={i === imgIndex}
                  >
                    <img src={src} alt="" loading="lazy" width="120" height="54" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="details__info">
            <p className="eyebrow">
              {shown.brand} · {shown.year} · {shown.category}
            </p>
            <h2 id="car-details-title" className="details__title">
              {shown.name}
            </h2>
            <PriceLabel car={shown} />

            {shown.isDemo && siteConfig.features.demoBadges && (
              <p className="notice">
                Data pada kendaraan ini adalah <strong>demo</strong> (nama, harga, spesifikasi, gambar). Konfirmasi detail resmi ke sales.
              </p>
            )}

            {shown.specs?.length > 0 && (
              <>
                <h3 className="details__h">Spesifikasi</h3>
                <dl className="specs">
                  {shown.fuel && (
                    <div>
                      <dt>Bahan bakar</dt>
                      <dd>{shown.fuel}</dd>
                    </div>
                  )}
                  {shown.drivetrain && (
                    <div>
                      <dt>Penggerak</dt>
                      <dd>{shown.drivetrain}</dd>
                    </div>
                  )}
                  {shown.specs.map((s) => (
                    <div key={s.label}>
                      <dt>{s.label}</dt>
                      <dd>{s.value}</dd>
                    </div>
                  ))}
                </dl>
              </>
            )}

            {shown.features?.length > 0 && (
              <>
                <h3 className="details__h">Fitur utama</h3>
                <ul className="features">
                  {shown.features.map((f) => (
                    <li key={f}>{f}</li>
                  ))}
                </ul>
              </>
            )}

            {shown.colors?.length > 0 && (
              <>
                <h3 className="details__h">
                  Warna: <span className="details__color-name">{shown.colors[colorIndex]?.name}</span>
                </h3>
                <div className="swatches" role="group" aria-label="Pilihan warna">
                  {shown.colors.map((c, i) => (
                    <button
                      key={c.name}
                      type="button"
                      className={i === colorIndex ? 'is-active' : ''}
                      style={{ '--swatch': c.hex }}
                      aria-label={c.name}
                      aria-pressed={i === colorIndex}
                      onClick={() => setColorIndex(i)}
                    />
                  ))}
                </div>
              </>
            )}

            <div className="details__actions">
              <button type="button" className="btn btn--primary" onClick={() => onSimulate(shown)}>
                SIMULATE CREDIT
              </button>
              <button type="button" className="btn btn--outline" onClick={() => onBook(shown)}>
                BOOK TEST DRIVE
              </button>
              <WhatsAppButton message={waMessages.car(shown, shown.colors?.[colorIndex]?.name)} label="ASK VIA WHATSAPP" variant="ghost" />
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
}
