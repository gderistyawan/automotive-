import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { siteConfig } from '../config/siteConfig.js';
import { cars, getCarById } from '../data/cars.js';
import { CREDIT_DISCLAIMER, MAX_TENOR_YEARS, MIN_TENOR_YEARS, calculateFlatCredit } from '../utils/creditCalculator.js';
import { formatIDR } from '../utils/format.js';
import { waMessages } from '../utils/whatsapp.js';
import WhatsAppButton from './WhatsAppButton.jsx';

const TENORS = Array.from({ length: MAX_TENOR_YEARS - MIN_TENOR_YEARS + 1 }, (_, i) => MIN_TENOR_YEARS + i);

export default function CreditSimulator({ carId, onCarChange }) {
  const initialCar = getCarById(carId);
  const [price, setPrice] = useState(initialCar?.price != null ? String(initialCar.price) : '');
  const [dpMode, setDpMode] = useState('percent');
  const [dpPercent, setDpPercent] = useState(String(siteConfig.credit.defaultDpPercent));
  const [dpAmount, setDpAmount] = useState('');
  const [tenor, setTenor] = useState(3);
  const [rate, setRate] = useState(String(siteConfig.credit.defaultRatePercent));
  const [fees, setFees] = useState('');

  // Saat kendaraan berubah (dari katalog atau dropdown), harga ikut diperbarui dari sumber data tunggal.
  useEffect(() => {
    const c = getCarById(carId);
    if (c) setPrice(c.price != null ? String(c.price) : '');
  }, [carId]);

  const result = useMemo(
    () => calculateFlatCredit({ price, dpMode, dpPercent, dpAmount, tenorYears: tenor, annualRatePercent: rate, extraFees: fees }),
    [price, dpMode, dpPercent, dpAmount, tenor, rate, fees]
  );

  const car = getCarById(carId);
  const carLabel = car ? `${car.brand} ${car.name} ${car.year}` : '';
  const priceIsDemo = car?.isDemo && siteConfig.features.demoBadges && String(car.price) === String(price);

  const switchDpMode = (mode) => {
    if (mode === dpMode) return;
    const p = Number(price);
    if (mode === 'amount') {
      const pct = Number(dpPercent);
      setDpAmount(Number.isFinite(p) && Number.isFinite(pct) ? String(Math.round((p * pct) / 100)) : '');
    } else {
      const amt = Number(dpAmount);
      if (Number.isFinite(p) && p > 0 && Number.isFinite(amt)) setDpPercent(String(Math.min(100, Math.max(0, Math.round((amt / p) * 1000) / 10))));
    }
    setDpMode(mode);
  };

  return (
    <section id="simulator" className="section simulator" aria-labelledby="sim-title">
      <div className="container">
        <header className="section__head">
          <p className="eyebrow">PLAN YOUR PURCHASE</p>
          <h2 id="sim-title" className="section__title">
            CREDIT <span className="accent">SIMULATOR</span>
          </h2>
          <p className="section__lead">
            <strong>Simulasi bunga flat.</strong> Gambaran awal cicilan — bukan penawaran pembiayaan resmi.
          </p>
        </header>

        <div className="sim">
          <div className="sim__form">
            <div className="field">
              <label htmlFor="sim-car">Pilihan kendaraan</label>
              <select id="sim-car" value={carId || 'custom'} onChange={(e) => onCarChange(e.target.value)}>
                <option value="custom">Input harga manual</option>
                {cars.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.brand} {c.name} {c.year}
                    {c.isDemo ? ' (demo)' : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className={`field ${result.errors?.price ? 'field--error' : ''}`}>
              <label htmlFor="sim-price">Harga kendaraan (Rp)</label>
              <input id="sim-price" type="number" inputMode="numeric" min="0" step="1000000" value={price} onChange={(e) => setPrice(e.target.value)} aria-invalid={!!result.errors?.price} aria-describedby="sim-price-hint" />
              <small id="sim-price-hint">
                {result.errors?.price ? <span className="error">{result.errors.price}</span> : price ? formatIDR(price) : 'Masukkan harga OTR.'}
                {priceIsDemo && <span className="badge badge--demo"> HARGA DEMO</span>}
              </small>
            </div>

            <div className="field">
              <span className="field__label" id="dp-mode-label">Uang muka (DP)</span>
              <div className="segmented" role="group" aria-labelledby="dp-mode-label">
                <button type="button" className={dpMode === 'percent' ? 'is-active' : ''} aria-pressed={dpMode === 'percent'} onClick={() => switchDpMode('percent')}>
                  Persentase
                </button>
                <button type="button" className={dpMode === 'amount' ? 'is-active' : ''} aria-pressed={dpMode === 'amount'} onClick={() => switchDpMode('amount')}>
                  Nominal
                </button>
              </div>
            </div>

            {dpMode === 'percent' ? (
              <div className={`field ${result.errors?.dp ? 'field--error' : ''}`}>
                <label htmlFor="sim-dp-pct">
                  DP: <strong>{dpPercent || 0}%</strong>
                </label>
                <input id="sim-dp-pct" type="range" min="0" max="90" step="1" value={Math.min(90, Number(dpPercent) || 0)} onChange={(e) => setDpPercent(e.target.value)} />
                <input type="number" min="0" max="100" step="0.5" value={dpPercent} onChange={(e) => setDpPercent(e.target.value)} aria-label="Persentase DP" aria-invalid={!!result.errors?.dp} />
                {result.errors?.dp && <small className="error">{result.errors.dp}</small>}
              </div>
            ) : (
              <div className={`field ${result.errors?.dp ? 'field--error' : ''}`}>
                <label htmlFor="sim-dp-amt">DP nominal (Rp)</label>
                <input id="sim-dp-amt" type="number" inputMode="numeric" min="0" step="1000000" value={dpAmount} onChange={(e) => setDpAmount(e.target.value)} aria-invalid={!!result.errors?.dp} />
                <small>{result.errors?.dp ? <span className="error">{result.errors.dp}</span> : dpAmount ? formatIDR(dpAmount) : 'Masukkan nominal DP.'}</small>
              </div>
            )}

            <div className="field">
              <span className="field__label" id="tenor-label">Tenor</span>
              <div className="segmented" role="group" aria-labelledby="tenor-label">
                {TENORS.map((t) => (
                  <button key={t} type="button" className={tenor === t ? 'is-active' : ''} aria-pressed={tenor === t} onClick={() => setTenor(t)}>
                    {t} th
                  </button>
                ))}
              </div>
            </div>

            <div className="field-row">
              <div className={`field ${result.errors?.annualRatePercent ? 'field--error' : ''}`}>
                <label htmlFor="sim-rate">Bunga flat per tahun (%)</label>
                <input id="sim-rate" type="number" min="0" max="100" step="0.1" value={rate} onChange={(e) => setRate(e.target.value)} aria-invalid={!!result.errors?.annualRatePercent} />
                {result.errors?.annualRatePercent && <small className="error">{result.errors.annualRatePercent}</small>}
              </div>
              <div className={`field ${result.errors?.extraFees ? 'field--error' : ''}`}>
                <label htmlFor="sim-fees">Biaya tambahan (Rp, opsional)</label>
                <input id="sim-fees" type="number" inputMode="numeric" min="0" step="100000" value={fees} onChange={(e) => setFees(e.target.value)} aria-invalid={!!result.errors?.extraFees} />
                {result.errors?.extraFees && <small className="error">{result.errors.extraFees}</small>}
              </div>
            </div>
          </div>

          <motion.div className="sim__result" aria-live="polite" layout>
            <p className="eyebrow">ESTIMASI CICILAN PER BULAN</p>
            {result.ok ? (
              <>
                <p className="sim__monthly">{formatIDR(result.monthlyInstallment)}</p>
                <dl className="sim__rows">
                  <div><dt>Harga kendaraan</dt><dd>{formatIDR(result.price)}</dd></div>
                  <div><dt>DP ({result.dpPercent.toFixed(1)}%)</dt><dd>{formatIDR(result.downPayment)}</dd></div>
                  <div><dt>Pokok pembiayaan</dt><dd>{formatIDR(result.principal)}</dd></div>
                  <div><dt>Total bunga ({result.annualRatePercent}% × {result.years} th)</dt><dd>{formatIDR(result.totalInterest)}</dd></div>
                  {result.extraFees > 0 && <div><dt>Biaya tambahan (di muka)</dt><dd>{formatIDR(result.extraFees)}</dd></div>}
                  <div className="sim__total"><dt>Total estimasi pembayaran</dt><dd>{formatIDR(result.totalPayment)}</dd></div>
                </dl>
                <div className="sim__assumptions">
                  <h3>Asumsi perhitungan</h3>
                  <ul>
                    <li>Metode bunga flat: pokok = harga − DP; bunga = pokok × bunga/tahun × tenor.</li>
                    <li>Cicilan = (pokok + bunga) ÷ {result.months} bulan.</li>
                    <li>Total pembayaran = DP + seluruh cicilan{result.extraFees > 0 ? ' + biaya tambahan' : ''}. Biaya tambahan dianggap dibayar di muka dan tidak berbunga.</li>
                  </ul>
                </div>
                <WhatsAppButton variant="primary" label="ASK SALES ABOUT THIS SIMULATION" message={waMessages.simulation(result, carLabel)} />
              </>
            ) : (
              <p className="sim__empty">Lengkapi input yang valid di sebelah kiri untuk melihat hasil simulasi.</p>
            )}
            <p className="disclaimer">{CREDIT_DISCLAIMER}</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
