import { motion } from 'framer-motion';
import { Car, Headphones, KeyRound, MessageCircle, Wallet } from 'lucide-react';
import { siteConfig } from '../config/siteConfig.js';

const ICONS = { car: Car, headphones: Headphones, wallet: Wallet, key: KeyRound, message: MessageCircle };

export default function WhyChooseUs() {
  return (
    <section className="section why" aria-labelledby="why-title">
      <div className="container">
        <header className="section__head">
          <p className="eyebrow">WHY DRIVEPULSE</p>
          <h2 id="why-title" className="section__title">
            WHY CHOOSE <span className="accent">US</span>
          </h2>
        </header>
        <ul className="why__grid">
          {siteConfig.whyChooseUs.map((item, i) => {
            const Icon = ICONS[item.icon] || Car;
            return (
              <motion.li
                key={item.title}
                className="why__item"
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
              >
                <span className="why__icon">
                  <Icon size={22} aria-hidden="true" />
                </span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </motion.li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
