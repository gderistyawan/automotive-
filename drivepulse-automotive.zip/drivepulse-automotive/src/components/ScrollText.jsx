import { useRef } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation.js';

// *kata* = aksen lime. dir: -1 = bergerak kanan→kiri, 1 = kiri→kanan.
const ROWS = [
  { text: 'DRIVE *YOUR* FUTURE', dir: -1, size: 'xl' },
  { text: 'BUILT TO *MOVE*', dir: 1, size: 'xl' },
  { text: 'ENGINEERED FOR *YOUR* JOURNEY', dir: -1, size: 'lg' },
  { text: 'YOUR NEXT CHAPTER *STARTS HERE*', dir: 1, size: 'lg' },
];

const MARQUEE = 'DRIVEPULSE AUTOMOTIVE  ✦  TEST DRIVE  ✦  EXPLORE  ✦  SIMULATE  ✦  ';

function renderText(text) {
  return text.split('*').map((part, i) => (i % 2 === 1 ? <em key={i}>{part}</em> : <span key={i}>{part}</span>));
}

function Marquee({ reverse = false }) {
  const content = MARQUEE.repeat(4);
  return (
    <div className={`marquee ${reverse ? 'marquee--reverse' : ''}`} aria-hidden="true">
      <div className="marquee__track">
        <span>{content}</span>
        <span>{content}</span>
      </div>
    </div>
  );
}

export default function ScrollText() {
  const ref = useRef(null);

  useScrollAnimation(
    ref,
    ({ scope, gsap, mobile }) => {
      // Di layar kecil teks dibungkus (wrap) agar tetap terbaca; gerakan horizontal dimatikan.
      if (mobile) return undefined;
      gsap.utils.toArray('.st-track', scope).forEach((track) => {
        const dir = Number(track.dataset.dir);
        gsap.fromTo(
          track,
          { x: dir < 0 ? '14vw' : '-14vw' },
          {
            x: dir < 0 ? '-14vw' : '14vw',
            ease: 'none',
            scrollTrigger: { trigger: track.parentElement, start: 'top bottom', end: 'bottom top', scrub: true },
          }
        );
      });
      return undefined;
    },
    []
  );

  return (
    <section className="scroll-text" ref={ref} aria-label="Tagline DRIVEPULSE">
      <Marquee />
      <div className="scroll-text__rows">
        {ROWS.map((r) => (
          <div className="st-row" key={r.text}>
            <p className={`st-track st-track--${r.size}`} data-dir={r.dir}>
              {renderText(r.text)}
            </p>
          </div>
        ))}
      </div>
      <Marquee reverse />
    </section>
  );
}
